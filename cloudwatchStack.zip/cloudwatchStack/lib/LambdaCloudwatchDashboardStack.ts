import {Aws, CfnOutput, Stack, StackProps} from "aws-cdk-lib";
import {Dashboard, GraphWidget, TextWidget} from 'aws-cdk-lib/aws-cloudwatch';
import * as lambda from "aws-cdk-lib/aws-lambda";
import {IFunction} from "aws-cdk-lib/aws-lambda";
import {Construct} from 'constructs';


type MapValue = string | number | string[] | Map<string, string>;

interface LambdaCloudwatchDashboardStackProps extends StackProps {
  dashboardName: string
}

export class LambdaCloudwatchDashboardStack extends Stack {
  private lambdaFunction: IFunction
  private dashboard: Dashboard
  constructor(scope: Construct, id: string, params: Map<String, MapValue>, props: LambdaCloudwatchDashboardStackProps) {
    super(scope, id, props);
    // Create CloudWatch Dashboard
    this.dashboard = new Dashboard(this, String(params.get("dashboardName")), {
      dashboardName: String(params.get("dashboardName"))
    })

    const createTextWidget = (description: String) => {
      this.dashboard.addWidgets(new TextWidget({
        markdown: `${description}`,
        height: 1,
        width: 24
      }))
    }

    const invocationMetricsGraphWidgets = () => {
      this.dashboard.addWidgets(new GraphWidget({
        title: "Invocations",
        left: [this.lambdaFunction.metricInvocations()],
        width: 24
      }))
    }

    const errorMetrics = () => {
      this.dashboard.addWidgets(new GraphWidget({
        title: "Errors",
        left: [this.lambdaFunction.metricErrors()],
        width: 24
      }))
    }

    const durationMetrics = () => {
      this.dashboard.addWidgets(new GraphWidget({
        title: "Duration",
        left: [this.lambdaFunction.metricDuration()],
        width: 24
      }))
    }


    const throttlesMetrics = () => {
      this.dashboard.addWidgets(new GraphWidget({
        title: "Throttles",
        left: [this.lambdaFunction.metricThrottles()],
        width: 24
      }))
    }

// Generate Outputs
    const cloudwatchDashboardURL = `https://${Aws.REGION}.console.aws.amazon.com/cloudwatch/home?region=${Aws.REGION}#dashboards:name=${props.dashboardName}`;
    new CfnOutput(this, 'DashboardOutput', {
      value: cloudwatchDashboardURL,
      description: `URL of ${params.get("dashboardName")} CloudWatch Dashboard`,
      exportName: `${this.dashboard.dashboardName}DashboardURL`
    });
    new CfnOutput(this, String(this.lambdaFunction.functionName), {
      value: this.lambdaFunction.functionName,
      description: 'Name of the Lambda Function',
      exportName: String(this.lambdaFunction.functionName)
    });

    Array.of(params.get("functions")).forEach(lambdaFunctionCon => {
      const lambdaFunctionConfig: Map<string, string>  = (<Map<string, string>>lambdaFunctionCon);
      this.lambdaFunction = lambda.Function.fromFunctionArn(
        this,
        String(this.lambdaFunction.functionName),
        `arn:aws:lambda:${Aws.REGION}:${Aws.ACCOUNT_ID}:function:${this.lambdaFunction.functionName}`
      );
      createTextWidget(String(lambdaFunctionConfig.get("description")))
      invocationMetricsGraphWidgets()
      errorMetrics()
      throttlesMetrics()
      durationMetrics()
    });

  }
}
