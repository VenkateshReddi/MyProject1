import {Aws, aws_s3, aws_sqs, CfnOutput, Stack, StackProps} from "aws-cdk-lib";
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import {Dashboard, GraphWidget, TextWidget} from 'aws-cdk-lib/aws-cloudwatch';
import {Construct} from 'constructs';


type MapValue = string | number | string[] | Map<string, string>;

interface SqsCloudwatchDashboardStackProps extends StackProps {
  dashboardName: string
}

export class SqsCloudwatchDashboardStack extends Stack {
  private queue: aws_sqs.IQueue
  private dashboard: Dashboard

  constructor(scope: Construct, id: string, params: Map<String, MapValue>, props: SqsCloudwatchDashboardStackProps) {
    super(scope, id, props);
    this.dashboard = new Dashboard(this, String(params.get("dashboardName")), {
      dashboardName: String(params.get("dashboardName"))
    })

    // Define a metric for the existing queue
    const bucketMetric = (metricName: String, statistics: String = "Average") =>
      new cloudwatch.Metric({
        namespace: 'AWS/SQS',
        metricName: `${metricName}`,
        dimensionsMap: {
          BucketName: this.queue.queueName,
          StorageType: 'StandardStorage',
        },
        statistic: `${statistics}`
      })

    const createTextWidget = (description: String) => {
      this.dashboard.addWidgets(new TextWidget({
        markdown: `${description}`,
        height: 1,
        width: 24
      }))
    }

    const createGraphWidgets = (title: string, metric: cloudwatch.Metric) => {
      this.dashboard.addWidgets(new GraphWidget({
        title: title,
        left: [metric],
        width: 24
      }))
    }

// Generate Outputs
    const generateOutputs = () => {
      const cloudwatchDashboardURL = `https://${Aws.REGION}.console.aws.amazon.com/cloudwatch/home?region=${Aws.REGION}#dashboards:name=${props.dashboardName}`;
      new CfnOutput(this, 'DashboardOutput', {
        value: cloudwatchDashboardURL,
        description: `URL of ${params.get("dashboardName")} CloudWatch Dashboard`,
        exportName: `${this.dashboard.dashboardName}DashboardURL`
      });
      new CfnOutput(this, String(this.queue.queueName), {
        value: this.queue.queueName,
        description: 'Name of the Lambda Function',
        exportName: String(this.queue.queueName)
      });
    }

    Array.of(params.get("functions")).forEach(lambdaFunctionCon => {
      const lambdaFunctionConfig: Map<string, string> = (<Map<string, string>>lambdaFunctionCon);
      this.queue = aws_sqs.Queue.fromQueueArn(
        this,
        String(lambdaFunctionConfig.get("name")),
        `arn:aws:sqs:${Aws.REGION}:${Aws.ACCOUNT_ID}:function:${lambdaFunctionConfig.get("name")}`
      );
      createTextWidget(String(lambdaFunctionConfig.get("description")))
      const bMetric = bucketMetric(String(lambdaFunctionConfig.get("metricName")), String(lambdaFunctionConfig.get("metricName")));
      createGraphWidgets(String(lambdaFunctionConfig.get("title")), bMetric)
      generateOutputs()
    });

  }
}
