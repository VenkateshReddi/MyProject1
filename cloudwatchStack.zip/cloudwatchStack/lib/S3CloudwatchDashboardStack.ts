import {Aws, aws_s3, CfnOutput, Stack, StackProps} from "aws-cdk-lib";
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import {Dashboard, GraphWidget, TextWidget} from 'aws-cdk-lib/aws-cloudwatch';
import {Construct} from 'constructs';


type MapValue = string | number | string[] | Map<string, string>;

interface S3CloudwatchDashboardStackProps extends StackProps {
  dashboardName: string
}

export class S3CloudwatchDashboardStack extends Stack {
  private bucket: aws_s3.IBucket
  private dashboard: Dashboard
  private sizeSummaryMetrics: cloudwatch.Metric[]

  constructor(scope: Construct, id: string, params: Map<String, MapValue>, props: S3CloudwatchDashboardStackProps) {
    super(scope, id, props);
    this.dashboard = new Dashboard(this, String(params.get("dashboardName")), {
      dashboardName: String(params.get("dashboardName"))
    })

    // Define a metric for the existing bucket
    const bucketMetric = (metricName: String, statistics: String = "Average") =>
      new cloudwatch.Metric({
        namespace: 'AWS/S3',
        metricName: `${metricName}`,
        dimensionsMap: {
          BucketName: this.bucket.bucketName,
          StorageType: 'StandardStorage',
        },
        statistic: `${statistics}`
      })

    const sizeSummaryMetrics = (bucketMetrics: cloudwatch.Metric[]) => {

    }

    const createTextWidget = (description: String) => {
      this.dashboard.addWidgets(new TextWidget({
        markdown: `${description}`,
        height: 1,
        width: 24
      }))
    }

    const createGraphWidgets = (title: string, metric: cloudwatch.Metric[]) => {
      this.dashboard.addWidgets(new GraphWidget({
        title: title,
        left: metric,
        width: 24
      }))
    }

// Generate Outputs
    const generateOutputs = () => {
      const cloudwatchDashboardURL = `https://${Aws.REGION}.console.aws.amazon.com/cloudwatch/home?region=${Aws.REGION}#dashboards:name=${props.dashboardName}`;
      new CfnOutput(this, 'DashboardOutput', {
        value: cloudwatchDashboardURL,
        description: `URL of ${params.get("dashboardName")} CloudWatch Dashboard`,
        exportName: `${this.dashboard.dashboardName}DashboardURL`
      });
      new CfnOutput(this, String(this.bucket.bucketName), {
        value: this.bucket.bucketName,
        description: 'Name of the Lambda Function',
        exportName: String(this.bucket.bucketName)
      });
    }

    Array.of(params.get("functions")).forEach(lambdaFunctionCon => {
      const lambdaFunctionConfig: Map<string, string> = (<Map<string, string>>lambdaFunctionCon);
      this.bucket = aws_s3.Bucket.fromBucketName(
        this,
        String(lambdaFunctionConfig.get("name")),
        `arn:aws:lambda:${Aws.REGION}:${Aws.ACCOUNT_ID}:function:${lambdaFunctionConfig.get("name")}`
      );
      createTextWidget(String(lambdaFunctionConfig.get("description")))
      const bMetric = bucketMetric(String(lambdaFunctionConfig.get("metricName")), String(lambdaFunctionConfig.get("metricName")));
      createGraphWidgets(String(lambdaFunctionConfig.get("title")), [bMetric])
      generateOutputs()
    });

  }
}
