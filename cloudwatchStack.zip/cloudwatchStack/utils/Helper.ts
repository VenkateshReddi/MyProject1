import * as fs from 'fs';

type MapValue = string | number | string[] | Map<String, String>;

function jsonFileToMap(filePath: string): Map<string, MapValue> {
  const map = new Map<string, MapValue>();

  try {
    const jsonData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    Object.keys(jsonData).forEach(key => {
      const value = jsonData[key];

      // Assuming the values can be strings, numbers, or arrays
      if (Array.isArray(value)) {
        map.set(key, value);
      } else if (typeof value === 'string' || typeof value === 'number') {
        map.set(key, value);
      }
    });
  } catch (err) {
    console.error('Error reading or parsing JSON file:', err);
  }

  return map;
}
